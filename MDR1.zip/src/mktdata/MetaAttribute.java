/* Generated SBE (Simple Binary Encoding) message codec */
package mktdata;

public enum MetaAttribute
{
    EPOCH,
    TIME_UNIT,
    SEMANTIC_TYPE
}
