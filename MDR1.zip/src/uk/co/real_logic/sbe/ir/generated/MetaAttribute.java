/* Generated SBE (Simple Binary Encoding) message codec */
package uk.co.real_logic.sbe.ir.generated;

public enum MetaAttribute
{
    EPOCH,
    TIME_UNIT,
    SEMANTIC_TYPE
}
